#include "stdio.h"

int main () {
	for (int i = 1; i <= 13; i++) printf("%d * 13 = %d\n", i, i*13);
	return 0;
}
