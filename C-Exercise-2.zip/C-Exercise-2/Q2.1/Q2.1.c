#include "stdio.h"

int main () {
	int i = 1;
	while (i <= 13) {
		printf("%d * 13 = %d\n", i, i*13);
		i++;
	}
	return 0;
}
