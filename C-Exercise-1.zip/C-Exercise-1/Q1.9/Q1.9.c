#include "graphics.h"

int main () {
	drawString("Computer Science Dept., University College London, Gower Street, London, WCIE 6BT",0,10);
	return 0;
}
